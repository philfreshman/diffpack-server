export const value = 116;
