export const value = 109;
