export const value = 102;
