export const value = 105;
