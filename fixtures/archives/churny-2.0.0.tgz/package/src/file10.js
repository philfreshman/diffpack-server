export const value = 110;
