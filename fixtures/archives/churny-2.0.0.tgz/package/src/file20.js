export const value = 120;
