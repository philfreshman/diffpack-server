export const value = 118;
