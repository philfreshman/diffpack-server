export const value = 106;
