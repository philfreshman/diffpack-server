export const n = 71;
