export const n = 292;
