export const n = 140;
