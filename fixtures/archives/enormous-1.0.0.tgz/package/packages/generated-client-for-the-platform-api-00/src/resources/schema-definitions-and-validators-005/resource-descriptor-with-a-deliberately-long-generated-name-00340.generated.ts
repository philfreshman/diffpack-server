export const n = 340;
