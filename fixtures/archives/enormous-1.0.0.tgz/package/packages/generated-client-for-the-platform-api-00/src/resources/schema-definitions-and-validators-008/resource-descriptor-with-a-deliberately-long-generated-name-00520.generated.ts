export const n = 520;
