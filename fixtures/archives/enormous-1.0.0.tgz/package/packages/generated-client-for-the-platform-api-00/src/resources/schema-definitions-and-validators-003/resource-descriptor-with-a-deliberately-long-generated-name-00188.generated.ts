export const n = 188;
