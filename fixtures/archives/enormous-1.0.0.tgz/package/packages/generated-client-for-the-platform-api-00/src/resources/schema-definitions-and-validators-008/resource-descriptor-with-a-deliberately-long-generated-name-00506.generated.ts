export const n = 506;
