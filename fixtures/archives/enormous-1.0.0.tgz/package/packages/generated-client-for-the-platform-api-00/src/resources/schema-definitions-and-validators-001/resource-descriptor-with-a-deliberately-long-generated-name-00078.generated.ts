export const n = 78;
