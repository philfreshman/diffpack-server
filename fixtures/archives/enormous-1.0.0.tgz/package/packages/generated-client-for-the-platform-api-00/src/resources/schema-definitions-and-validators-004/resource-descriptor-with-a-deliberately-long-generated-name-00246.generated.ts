export const n = 246;
