export const n = 190;
