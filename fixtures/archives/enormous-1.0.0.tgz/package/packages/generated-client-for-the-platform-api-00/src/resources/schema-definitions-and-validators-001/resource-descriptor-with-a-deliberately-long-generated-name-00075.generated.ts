export const n = 75;
