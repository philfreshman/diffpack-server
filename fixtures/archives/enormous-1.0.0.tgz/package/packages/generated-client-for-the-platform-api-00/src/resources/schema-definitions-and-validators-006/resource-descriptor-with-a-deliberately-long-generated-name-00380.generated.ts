export const n = 380;
