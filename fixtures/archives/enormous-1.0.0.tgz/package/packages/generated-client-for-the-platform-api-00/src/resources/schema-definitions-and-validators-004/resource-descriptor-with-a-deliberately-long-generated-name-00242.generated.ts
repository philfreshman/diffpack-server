export const n = 242;
