export const n = 70;
