export const n = 375;
