export const n = 255;
