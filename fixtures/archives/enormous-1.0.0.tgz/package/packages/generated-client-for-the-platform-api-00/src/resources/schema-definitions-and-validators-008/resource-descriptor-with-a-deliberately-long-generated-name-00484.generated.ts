export const n = 484;
