export const n = 350;
