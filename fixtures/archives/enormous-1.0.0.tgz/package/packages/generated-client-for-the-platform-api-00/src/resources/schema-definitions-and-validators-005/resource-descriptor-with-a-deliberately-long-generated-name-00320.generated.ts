export const n = 320;
