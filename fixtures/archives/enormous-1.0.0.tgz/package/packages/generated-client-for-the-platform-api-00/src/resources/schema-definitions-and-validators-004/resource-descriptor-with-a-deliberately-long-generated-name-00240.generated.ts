export const n = 240;
