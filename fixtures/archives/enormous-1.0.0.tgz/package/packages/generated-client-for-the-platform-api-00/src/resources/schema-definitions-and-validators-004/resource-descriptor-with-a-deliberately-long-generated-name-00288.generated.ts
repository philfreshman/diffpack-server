export const n = 288;
