export const n = 530;
