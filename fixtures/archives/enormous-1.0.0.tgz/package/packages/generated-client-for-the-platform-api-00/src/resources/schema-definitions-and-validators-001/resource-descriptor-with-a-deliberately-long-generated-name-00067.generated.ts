export const n = 67;
