export const n = 92;
