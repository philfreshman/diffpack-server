export const n = 220;
