export const n = 65;
