export const n = 80;
