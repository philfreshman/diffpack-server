export const n = 73;
