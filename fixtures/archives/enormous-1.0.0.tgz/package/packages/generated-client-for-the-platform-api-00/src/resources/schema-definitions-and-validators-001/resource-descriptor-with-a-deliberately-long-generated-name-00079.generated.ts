export const n = 79;
