export const n = 90;
