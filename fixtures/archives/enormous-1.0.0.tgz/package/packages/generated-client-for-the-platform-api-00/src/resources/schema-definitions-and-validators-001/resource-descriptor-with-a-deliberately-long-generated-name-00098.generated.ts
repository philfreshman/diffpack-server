export const n = 98;
