export const n = 96;
