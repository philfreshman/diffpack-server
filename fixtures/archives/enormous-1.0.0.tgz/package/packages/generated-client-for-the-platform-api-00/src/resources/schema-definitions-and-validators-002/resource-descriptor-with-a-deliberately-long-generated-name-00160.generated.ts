export const n = 160;
