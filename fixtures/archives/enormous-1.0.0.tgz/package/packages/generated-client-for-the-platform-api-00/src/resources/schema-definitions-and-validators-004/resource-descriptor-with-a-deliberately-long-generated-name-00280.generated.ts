export const n = 280;
