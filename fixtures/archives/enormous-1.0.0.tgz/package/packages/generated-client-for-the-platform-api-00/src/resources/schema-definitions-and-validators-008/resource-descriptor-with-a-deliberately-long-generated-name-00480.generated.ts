export const n = 480;
