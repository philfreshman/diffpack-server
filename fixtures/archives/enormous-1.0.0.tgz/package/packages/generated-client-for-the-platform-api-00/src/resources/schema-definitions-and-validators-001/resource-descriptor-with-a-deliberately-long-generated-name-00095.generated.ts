export const n = 95;
