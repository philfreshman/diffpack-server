export const n = 580;
