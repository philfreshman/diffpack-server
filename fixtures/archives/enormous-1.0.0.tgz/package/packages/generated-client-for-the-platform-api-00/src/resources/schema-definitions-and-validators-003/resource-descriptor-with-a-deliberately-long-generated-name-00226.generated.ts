export const n = 226;
