export const n = 256;
