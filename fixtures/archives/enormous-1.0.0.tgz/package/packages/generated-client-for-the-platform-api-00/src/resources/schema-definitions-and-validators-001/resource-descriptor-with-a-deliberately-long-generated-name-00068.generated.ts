export const n = 68;
