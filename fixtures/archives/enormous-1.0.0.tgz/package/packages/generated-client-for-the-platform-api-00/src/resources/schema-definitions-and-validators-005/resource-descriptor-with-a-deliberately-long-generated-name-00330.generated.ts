export const n = 330;
