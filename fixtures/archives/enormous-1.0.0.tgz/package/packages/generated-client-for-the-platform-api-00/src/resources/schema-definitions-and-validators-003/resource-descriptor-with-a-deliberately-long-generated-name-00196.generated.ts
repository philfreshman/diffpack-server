export const n = 196;
