export const n = 142;
