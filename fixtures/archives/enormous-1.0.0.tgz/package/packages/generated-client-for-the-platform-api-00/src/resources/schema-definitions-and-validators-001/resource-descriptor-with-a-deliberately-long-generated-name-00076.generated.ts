export const n = 76;
