export const n = 105;
