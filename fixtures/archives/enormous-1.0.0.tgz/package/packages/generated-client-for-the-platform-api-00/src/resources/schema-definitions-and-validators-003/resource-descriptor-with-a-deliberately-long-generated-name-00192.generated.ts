export const n = 192;
