export const n = 82;
