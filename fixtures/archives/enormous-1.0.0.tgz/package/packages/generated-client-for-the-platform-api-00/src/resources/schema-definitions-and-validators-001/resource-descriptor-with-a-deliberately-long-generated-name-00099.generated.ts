export const n = 99;
