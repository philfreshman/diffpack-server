export const n = 230;
