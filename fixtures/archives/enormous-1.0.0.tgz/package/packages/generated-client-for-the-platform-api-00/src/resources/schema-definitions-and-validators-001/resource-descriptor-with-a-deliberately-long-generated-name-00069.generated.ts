export const n = 69;
