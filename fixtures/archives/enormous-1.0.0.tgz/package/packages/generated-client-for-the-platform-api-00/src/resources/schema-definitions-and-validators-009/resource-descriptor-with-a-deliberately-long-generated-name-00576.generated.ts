export const n = 576;
