export const n = 232;
