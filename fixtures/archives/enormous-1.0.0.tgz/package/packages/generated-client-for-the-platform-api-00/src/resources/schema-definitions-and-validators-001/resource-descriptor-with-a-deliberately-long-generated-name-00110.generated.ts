export const n = 110;
