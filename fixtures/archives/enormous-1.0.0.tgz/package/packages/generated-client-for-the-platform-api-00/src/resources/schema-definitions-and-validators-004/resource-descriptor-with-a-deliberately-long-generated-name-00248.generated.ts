export const n = 248;
