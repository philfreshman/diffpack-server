export const n = 72;
