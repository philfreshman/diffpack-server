export const n = 66;
