export const n = 194;
