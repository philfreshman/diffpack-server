export const n = 505;
