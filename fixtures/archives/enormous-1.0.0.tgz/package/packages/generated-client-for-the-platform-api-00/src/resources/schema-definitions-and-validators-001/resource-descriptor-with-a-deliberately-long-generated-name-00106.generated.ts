export const n = 106;
