export const n = 550;
