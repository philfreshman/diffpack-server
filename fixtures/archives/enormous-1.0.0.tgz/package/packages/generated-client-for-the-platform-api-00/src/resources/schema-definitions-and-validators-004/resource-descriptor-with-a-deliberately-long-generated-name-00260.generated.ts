export const n = 260;
