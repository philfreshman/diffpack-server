declare const version: string;
