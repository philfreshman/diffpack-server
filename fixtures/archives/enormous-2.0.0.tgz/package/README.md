Generated clients for the platform API.

Nothing in this file resembles a resource descriptor, so no removal pairs with
it and the statuses below stay the fixture's rather than the threshold's.
