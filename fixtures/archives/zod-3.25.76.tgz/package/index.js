export const zod = 3;
