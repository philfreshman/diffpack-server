from distutils.core import setup

setup(name="numpy", version="1.9.0")
