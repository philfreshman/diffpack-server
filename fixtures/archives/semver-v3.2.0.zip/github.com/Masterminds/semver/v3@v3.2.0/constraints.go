package semver

func Check() bool { return true }
