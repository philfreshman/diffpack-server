export const value = 6;
