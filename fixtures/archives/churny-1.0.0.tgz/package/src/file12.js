export const value = 12;
