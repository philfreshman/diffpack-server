export const value = 20;
