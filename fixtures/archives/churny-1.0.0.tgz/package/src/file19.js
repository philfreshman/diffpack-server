export const value = 19;
