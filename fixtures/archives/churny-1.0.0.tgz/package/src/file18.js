export const value = 18;
