export const value = 23;
