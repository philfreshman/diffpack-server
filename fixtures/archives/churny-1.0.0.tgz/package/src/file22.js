export const value = 22;
