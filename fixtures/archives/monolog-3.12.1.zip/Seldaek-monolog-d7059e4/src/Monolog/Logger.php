<?php

namespace Monolog;

class Logger
{
    public const VERSION = '3.12.1';
}
