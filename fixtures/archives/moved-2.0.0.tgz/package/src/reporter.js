import { format } from "./format";

export function report(rows) {
  const lines = rows.map(format);
  lines.sort();
  return lines.join("\n");
}

export default report;
