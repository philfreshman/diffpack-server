from setuptools import setup

setup(name="requests", version="2.31.0")
