export const n = 1480;
