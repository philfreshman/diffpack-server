export const n = 1472;
