export const n = 1400;
