export const n = 1440;
