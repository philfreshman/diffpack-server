export const n = 1492;
