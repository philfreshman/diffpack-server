export const n = 1296;
