export const n = 1244;
