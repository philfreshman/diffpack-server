export const n = 1234;
