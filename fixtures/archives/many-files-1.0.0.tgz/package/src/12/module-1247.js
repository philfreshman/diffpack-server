export const n = 1247;
