export const n = 1275;
