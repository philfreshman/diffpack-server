export const n = 1224;
