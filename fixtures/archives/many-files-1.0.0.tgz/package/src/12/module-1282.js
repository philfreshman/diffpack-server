export const n = 1282;
