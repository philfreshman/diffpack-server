export const n = 1276;
