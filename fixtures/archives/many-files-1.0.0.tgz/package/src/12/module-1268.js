export const n = 1268;
