export const n = 1272;
