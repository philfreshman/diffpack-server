export const n = 1288;
