export const n = 1228;
