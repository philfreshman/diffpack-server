export const n = 1248;
