export const n = 1226;
