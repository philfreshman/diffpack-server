export const n = 1290;
