export const n = 1200;
