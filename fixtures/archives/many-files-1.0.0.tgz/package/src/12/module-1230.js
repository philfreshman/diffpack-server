export const n = 1230;
