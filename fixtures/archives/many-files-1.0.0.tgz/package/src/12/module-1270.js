export const n = 1270;
