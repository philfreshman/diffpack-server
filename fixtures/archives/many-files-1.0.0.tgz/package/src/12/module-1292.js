export const n = 1292;
