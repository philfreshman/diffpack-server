export const n = 1260;
