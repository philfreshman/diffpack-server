export const n = 1206;
