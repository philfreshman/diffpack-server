export const n = 1252;
