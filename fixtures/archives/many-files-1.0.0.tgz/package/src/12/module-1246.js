export const n = 1246;
