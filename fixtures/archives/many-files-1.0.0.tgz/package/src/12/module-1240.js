export const n = 1240;
