export const n = 1242;
