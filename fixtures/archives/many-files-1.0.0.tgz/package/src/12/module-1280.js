export const n = 1280;
