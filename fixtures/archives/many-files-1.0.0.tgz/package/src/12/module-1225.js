export const n = 1225;
