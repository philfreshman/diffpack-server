export const n = 1250;
