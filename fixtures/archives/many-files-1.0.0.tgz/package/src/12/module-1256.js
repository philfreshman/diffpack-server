export const n = 1256;
