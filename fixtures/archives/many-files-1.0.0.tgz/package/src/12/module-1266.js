export const n = 1266;
