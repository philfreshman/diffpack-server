export const n = 1278;
