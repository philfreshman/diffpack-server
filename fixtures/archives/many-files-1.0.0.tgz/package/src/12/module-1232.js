export const n = 1232;
