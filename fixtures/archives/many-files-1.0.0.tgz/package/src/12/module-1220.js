export const n = 1220;
