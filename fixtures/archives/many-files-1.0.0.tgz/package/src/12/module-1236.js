export const n = 1236;
