export const n = 1293;
