export const n = 2246;
