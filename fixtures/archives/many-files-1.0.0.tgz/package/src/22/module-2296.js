export const n = 2296;
