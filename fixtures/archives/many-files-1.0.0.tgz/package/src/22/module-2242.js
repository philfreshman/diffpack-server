export const n = 2242;
