export const n = 2288;
