export const n = 2200;
