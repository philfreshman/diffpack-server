export const n = 2280;
