export const n = 2250;
