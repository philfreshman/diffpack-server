export const n = 2260;
