export const n = 1380;
