export const n = 1372;
