export const n = 1320;
