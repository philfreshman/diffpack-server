export const n = 1344;
