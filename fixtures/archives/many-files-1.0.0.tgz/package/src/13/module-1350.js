export const n = 1350;
