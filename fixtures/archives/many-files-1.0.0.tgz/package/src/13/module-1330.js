export const n = 1330;
