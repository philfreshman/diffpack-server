export const n = 1375;
