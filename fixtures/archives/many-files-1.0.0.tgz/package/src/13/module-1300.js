export const n = 1300;
