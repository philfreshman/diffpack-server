export const n = 1342;
