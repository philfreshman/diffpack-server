export const n = 1352;
