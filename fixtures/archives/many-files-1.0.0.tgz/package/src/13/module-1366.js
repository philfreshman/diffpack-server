export const n = 1366;
