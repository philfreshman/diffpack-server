export const n = 1332;
