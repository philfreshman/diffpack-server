export const n = 1340;
