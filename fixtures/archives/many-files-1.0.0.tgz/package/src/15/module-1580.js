export const n = 1580;
