export const n = 1530;
