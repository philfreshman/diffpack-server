export const n = 1550;
