from setuptools import setup

setup(name="sneaky", version="1.0.0")
