// caf�
const pad1 = 0;
const pad2 = 0;
const pad3 = 0;
const pad4 = 0;
const pad5 = 0;
const pad6 = 0;
const pad7 = 0;
const pad8 = 0;
export const far = 1;
