export const stable = 1;
export const alsoStable = 2;
