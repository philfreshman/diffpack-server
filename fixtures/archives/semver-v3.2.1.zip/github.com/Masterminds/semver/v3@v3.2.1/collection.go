package semver

type Collection []string
